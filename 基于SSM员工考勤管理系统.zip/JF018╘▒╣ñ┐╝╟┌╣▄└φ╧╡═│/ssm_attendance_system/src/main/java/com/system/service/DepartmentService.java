package com.system.service;

import com.system.pojo.Department;

import java.util.List;

/**
 * Created by Jacey on 2017/6/30.
 */
public interface DepartmentService {

    List<Department> finAll() throws Exception;

}
